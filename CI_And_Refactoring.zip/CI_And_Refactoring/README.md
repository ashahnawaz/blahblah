<a href="https://codeclimate.com/github/RafidSaad/CI_And_Refactoring"><img src="https://codeclimate.com/github/RafidSaad/CI_And_Refactoring/badges/gpa.svg" /></a>
<a href="https://codeclimate.com/github/RafidSaad/CI_And_Refactoring/coverage"><img src="https://codeclimate.com/github/RafidSaad/CI_And_Refactoring/badges/coverage.svg" /></a>
<a href="https://codeclimate.com/github/RafidSaad/CI_And_Refactoring"><img src="https://codeclimate.com/github/RafidSaad/CI_And_Refactoring/badges/issue_count.svg" /></a>

# Java CI And Refactoring

We intend to refactor this open-source repository https://github.com/ashish1294/ChessOOP and use different CI tools in the process.
